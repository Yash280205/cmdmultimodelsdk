highlevel={}
highlevel["SOCIAL_IQ_COVAREP"]="http://immortal.multicomp.cs.cmu.edu/Social-IQ/acoustic/SOCIAL_IQ_COVAREP.csd"
highlevel["SOCIAL-IQ_QA_BERT_LASTLAYER_BINARY_CHOICE"]="http://immortal.multicomp.cs.cmu.edu/Social-IQ/qa/SOCIAL-IQ_QA_BERT_LASTLAYER_BINARY_CHOICE.csd"
highlevel["SOCIAL-IQ_QA_BERT_MULTIPLE_CHOICE"]="http://immortal.multicomp.cs.cmu.edu/Social-IQ/qa/SOCIAL-IQ_QA_BERT_MULTIPLE_CHOICE.csd"
highlevel["SOCIAL_IQ_TRANSCRIPT_RAW_CHUNKS_BERT"]="http://immortal.multicomp.cs.cmu.edu/Social-IQ/transcript/SOCIAL_IQ_TRANSCRIPT_RAW_CHUNKS_BERT.csd"
highlevel["SOCIAL_IQ_DENSENET161_1FPS"]="http://immortal.multicomp.cs.cmu.edu/Social-IQ/vision/SOCIAL_IQ_DENSENET161_1FPS.csd"
highlevel["SOCIAL_IQ_VGG_1FPS"]="http://immortal.multicomp.cs.cmu.edu/Social-IQ/vision/SOCIAL_IQ_VGG_1FPS.csd"
