Paul Pu Liang has re-implemented the original version of Memory Fusion Network in pytorch: https://github.com/pliang279/MFN

He is among the rising stars of multimodal machine learning. You can follow him here:

http://www.cs.cmu.edu/~pliang/

