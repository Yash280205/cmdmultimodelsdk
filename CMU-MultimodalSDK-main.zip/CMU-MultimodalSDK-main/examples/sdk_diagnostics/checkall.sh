python2 scenario1.py
rm cmumosi -r
python3 scenario1.py
