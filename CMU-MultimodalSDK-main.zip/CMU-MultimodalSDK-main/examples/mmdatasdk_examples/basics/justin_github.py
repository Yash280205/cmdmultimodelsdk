print ("Some of the content in this tutorial may be outdated, however it is an amazing tutorial nonetheless: https://github.com/Justin1904/CMU-MultimodalSDK-Tutorials")
print ("Special thanks to Zhun Liu @ justin1904")
