SDK Diagnostic Tools

These are mostly used to make sure new functionalities don't break things.
